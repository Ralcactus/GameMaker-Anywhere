namespace libdisableclose {

  bool window_get_close_enabled(void *window);
  bool window_set_close_enabled(void *window, bool enabled);

} // namespace libdisableclose
