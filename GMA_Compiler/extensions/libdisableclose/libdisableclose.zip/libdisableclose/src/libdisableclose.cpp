#include "libdisableclose.h"

#if defined(_WIN32)
#include <windows.h>
#elif (defined(__APPLE__) && defined(__MACH__))
#include <AppKit/AppKit.h>
#elif ((defined(__linux__) && !defined(__ANDROID__)) || (defined(__FreeBSD__) || defined(__DragonFly__) || defined(__NetBSD__) || defined(__OpenBSD__)) || defined(__sun))
#include <X11/Xlib.h>
#endif

namespace libdisableclose {

  bool window_get_close_enabled(void *window) {
    if (!window) {
      return false;
    }
    #if defined(_WIN32)
    HMENU hmenu;
    HWND hwnd = (HWND)window;
    if (!IsWindow(hwnd)) {
      return false;
    }
    if (!(hmenu = GetSystemMenu(hwnd, false))) { 
      return false;
    }
    MENUITEMINFO mii = { 
      sizeof(MENUITEMINFO)
    };
    mii.fMask = MIIM_STATE;
    if (GetMenuItemInfo(hmenu, SC_CLOSE, FALSE, &mii)) {
      if (!(mii.fState & MFS_DISABLED)) {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
    #elif (defined(__APPLE__) && defined(__MACH__))
    NSWindow *nswnd = (NSWindow *)window;
    return [[nswnd standardWindowButton:NSWindowCloseButton] enabled];
    #elif ((defined(__linux__) && !defined(__ANDROID__)) || (defined(__FreeBSD__) || defined(__DragonFly__) || defined(__NetBSD__) || defined(__OpenBSD__)) || defined(__sun))
    Display *xdpy = XOpenDisplay(nullptr);
    if (xdpy) {
      Window xwnd = (Window)(unsigned long long)window;
      Atom wm_delmsg = XInternAtom(xdpy, "WM_DELETE_WINDOW", true);
      if (!wm_delmsg) {
        goto done;
      }
      int count = 0;
      Atom *protocols = nullptr;
      if (XGetWMProtocols(xdpy, xwnd, &protocols, &count) == 0) {
        goto done;
      }
      bool found = false;
      for (int i = 0; i < count; ++i) {
        if (protocols[i] == wm_delmsg) {
          found = true;
          break;
        }
      }
      done:
      if (protocols) {
        XFree(protocols);
      }
      XCloseDisplay(xdpy);
      if (!err) {
        return found;
      }
    }
    return false;
    #endif
  }

  bool window_set_close_enabled(void *window, bool enabled) {
    if (!window) {
      return false;
    }
    #if defined(_WIN32)
    HMENU hmenu;
    UINT dw_extra;
    HWND hwnd = (HWND)window;
    if (!IsWindow(hwnd)) {
      return false;
    }
    if (!(hmenu = GetSystemMenu(hwnd, false))) { 
      return false;
    }
    dw_extra = ((enabled) ? MF_ENABLED : (MF_DISABLED | MF_GRAYED));
    return (EnableMenuItem(hmenu, SC_CLOSE, MF_BYCOMMAND | dw_extra) != -1);
    #elif (defined(__APPLE__) && defined(__MACH__))
    NSWindow *nswnd = (NSWindow *)window;
    [[nswnd standardWindowButton:NSWindowCloseButton] setEnabled:((enabled) ? YES : NO)];
    return true;
    #elif ((defined(__linux__) && !defined(__ANDROID__)) || (defined(__FreeBSD__) || defined(__DragonFly__) || defined(__NetBSD__) || defined(__OpenBSD__)) || defined(__sun))
    Display *xdpy = XOpenDisplay(nullptr);
    if (xdpy) {
      Atom wm_delmsg = XInternAtom(dpy, "WM_DELETE_WINDOW", false);
      if (wm_delmsg) {
        Status status = 0;
        Window xwnd = (Window)(unsigned long long)window;
        if (enabled) {
          Atom protocols[] = { wm_delmsg };
          status = XSetWMProtocols(xdpy, xwnd, protocols, 1);
        } else {
          status = XSetWMProtocols(xdpy, xwnd, nullptr, 0);
        }
        XFlush(xdpy);
        XCloseDisplay(xdpy);
        if (status) { 
          return true;
        }
      }
    }
    return false;
    #endif
  }

} // namespace libdisableclose
